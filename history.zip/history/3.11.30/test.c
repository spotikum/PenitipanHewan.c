#include <stdio.h>
#define MAXCHAR 1

int main(){
    FILE * head;
    char str[MAXCHAR];
    int text;
    head = fopen("file/test.txt", "r");
    while (fgets(str, MAXCHAR, head)){
        text = str;
        printf("%d", text);
    }
    fclose(head);
}