#include "head.h"
#include "input.h"
#include "output.h"

int main(void) {
    int kondisi = Guide(), user;
    while (kondisi != 0)
    {
        if (kondisi == 1)
        {
            kondisi = Head(user = kondisi);
            while (kondisi != 0)
            {
                if (kondisi == 1)
                {
                    kondisi = Input(user);
                }
                else if (kondisi == 2)
                {
                    kondisi = Output();
                }
                else{
                    kondisi = Head(user);
                }
            }
            kondisi = Guide();
        }
        else if (kondisi == 2)
        {
            kondisi = Guide();
        }
    }
    puts("Bye");
    return 0;
}