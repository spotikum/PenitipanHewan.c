#include <stdio.h>
#include <time.h>

int Input(){
    system("clear||clr");
    HeadText();
    
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);
        
    // Setting wktu menjadi kode
    // Hari dikali 100 dan bulan dikali 10
    time_->tm_mday *= 100;

    if (time_->tm_mon+1 < 10)
        time_->tm_mon *= 10;
        
    // Pembuatan kode dengan menggabungkan hari dan bulan
    int kode;    
    kode = time_->tm_mday + time_->tm_mon+1;
    if (kode < 1000)
        kode *= 10;
    // end

    char kosong[50],namaPemilik[50], namaHewan[50], jenisHewan[50];
    printf("Nama Pemilik    : ");
    scanf("%s",&namaPemilik);
    printf("Nama Hewan      : ");
    scanf("%s",&namaHewan);
    printf("Jenis Hewan     : ");
    scanf("%s",&jenisHewan);

    // Pembuatan file txt dengan nama dari kode
    char code[12];
    code[0] = 'l';
    code[1] = 'o';
    code[2] = 'g';
    code[3] = '/';
        // Mengubah integer menjadi char
        int tempkode[4];
        tempkode[0] = (kode / 1000);
        tempkode[1] = (kode - (tempkode[0] * 1000)) / 100;
        tempkode[2] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100)))/10;
        tempkode[3] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100) + (tempkode[2] * 10)));
        for (int i = 0; i < 4; i++){
            code[i+4] = tempkode[i]+'0';
        }
        // end
    code[8] = '.';
    code[9] = 't';
    code[10] = 'x';
    code[11] = 't';
    // end

    // Membuat struk dalam file txt
    FILE * struk;
    struk = fopen("/home/spot/Desktop/struk.txt", "w");
    fprintf(struk, ".__________________________________________\n");
    fprintf(struk, "\n");
    fprintf(struk, "               Titip Hewan Kuy\n");
    fprintf(struk, "\n");
    fprintf(struk, " Nama Pemilik      : %s\n", namaPemilik);
    fprintf(struk, " Nama Hewan        : %s\n", namaHewan);
    fprintf(struk, " Jenis Hewan       : %s\n", jenisHewan);
    fprintf(struk, " Kode Pengambilan  : %d\n", kode);
    fprintf(struk, "__________________________________________\n");
    fclose(struk);
    // end

    // Membuat struk dengan nama dari kode sebagai arsip
    struk = fopen(code, "w");
    fprintf(struk, "%d\n", kode);
    fprintf(struk, "%s\n", kosong);
    fprintf(struk, "%s\n", namaPemilik);
    fprintf(struk, "%s\n", namaHewan);
    fprintf(struk, "%s\n", jenisHewan);
    fclose(struk);
    // end

    // Mengulang ke baris awal atau berhenti
    char input;
    printf("Lagi? [y/t] : ");
    scanf("%s",&input);
    if (input == 'y'){
        return 1;
    }else{
        return 3;
    }
    // end
}