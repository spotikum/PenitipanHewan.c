#include <stdio.h>
#include <stdlib.h>
#define MAXCHAR 1000

void GuideMain(){
    FILE * guide;
    char str[MAXCHAR];
    guide = fopen("file/guide.txt", "r");
    while (
        fgets(str, MAXCHAR, guide)
        )
        printf("%s", str);
    fclose(guide);
}

void GuideMenu(){
    FILE * guide;
    char str[MAXCHAR];
    guide = fopen("file/guideMenu.txt", "r");
    while (
        fgets(str, MAXCHAR, guide)
        )
        printf("%s", str);
    fclose(guide);
}

int Guide(){
    system("clear||clr");
    printf("\n");

    HeadText();

    char input;
    printf("*Type h for help ");
    printf("\n\n> ");
    scanf("%s", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'l')
    {
        int kode = Login();
        return kode;
    }else if (input == 'h')
    {
        system("clear||clr");
        GuideMain();
        printf("\n\nType any key > ");
        scanf("%s", &input);
        return 2;
    }else{
        return 2;
    }
}

void HeadText(){
    FILE * head;
    char str[MAXCHAR];
    head = fopen("file/head.txt", "r");
    while (
        fgets(str, MAXCHAR, head)
        )
        printf("%s", str);
    fclose(head);
}

int Head(){
    system("clear||clr");

    HeadText();

    char input;
    printf("\n\n*Type h for help\n\n");
    printf("admin > ");
    scanf("%s", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'i'){
        return 1;
    }else if (input == 'o'){
        return 2;
    }else if (input == 'h')
    {
        system("clear||clr");
        GuideMenu();
        printf("\n\nType any key > ");
        scanf("%s", &input);
        return 3;
    }else{
        return 3;
    }
}

int Login()
{
    char uname[]="admin", password[]="ok", id[20], p[20];
    int n=1, x, y;

    do{
      system("clear||clr");
         printf("\nUsername : ");
         scanf("%s", &id);
         fflush(stdout);

         printf("Password : ");
         scanf("%s", &p);
         fflush(stdout);

         x=strcmp(id, uname);
         y=strcmp(p, password);

         if(x==0 && y==0){
           return 1;
           break;
         }else {
           printf("\nWrong Password, try again", 3-n);
            n++;}

         if(n>5){
          printf("\nAccess Denied");
          }

       }while (n<=5);
    return 0;
}