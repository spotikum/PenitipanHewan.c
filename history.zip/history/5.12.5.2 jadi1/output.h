#define MAXCODE 10

struct DataHewanOut;
char pegawai[MAX_NAMA];

struct DataHewanOut{
    char kode[MAX_NAMA];
    int kode_hewan;
    int jenis_hewan;
    int menit;
    int jam;
    int hari;
    int bulan;
    int ras;
    char telepon[MAX_NAMA];
    char jenisHewan[MAX_NAMA];
    char namaPemilik[MAX_NAMA];
    char namaHewan[MAX_NAMA];
};

struct Harga{
    char nama_harga[MAX_NAMA];
    int satuan_harga;
};


struct DataHewanOut data;
struct DataHewanOut hrg;
struct Harga nominal;
int harga_total, harga_bayar, harga_kembalian;

int Output(void){
    HeadText(); User();
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);

    char inputKode[MAXCODE];

    printf("\nInput Kode : ");
    scanf("%s", &inputKode);

    FILE *log;
    log = fopen("file/log.txt","r");
    while(!feof(log)){
        fscanf(log,"%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s", &data.kode, &tmp, &data.namaPemilik, &data.namaHewan, &data.jenisHewan, 
        &data.kode_hewan, &data.jenis_hewan, &data.menit, &data.jam, &data.hari, &data.bulan, &data.telepon);
        if (strcmp(inputKode,data.kode) == 0)
        {
            break;
        }
    }
    fclose(log);

    log = fopen("file/harga.txt","r");
    while(!feof(log)){
        fscanf(log,"%s\t%s\t%d", &hrg.namaHewan, &hrg.jenisHewan, &nominal.satuan_harga);
        if (strcmp(data.namaHewan,hrg.namaHewan) == 0)
        {
            if (strcmp(data.jenisHewan,hrg.jenisHewan) == 0)
            {
                printf("%d", nominal.satuan_harga);
                break;
            }
            
        }
    }
    fclose(log);

    harga_total = nominal.satuan_harga * ((time_->tm_mday + 1) - data.hari);

    HeadText(); User();
    printf("\nTotal Bayar           : %d", harga_total);
    printf("\nUang yang dibayarkan  : ");
    scanf("%d", &harga_bayar); harga_kembalian = harga_bayar - harga_total;

    FILE * struk = fopen("struk.txt","w");
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\n                              Titip Hewan Kuy");
    fprintf(struk, "\n");
    fprintf(struk, "\n Jln. Kenangan Indah No.1 - Karangasem - Bali");
    fprintf(struk, "\n Hp/Wa 081337335678");
    fprintf(struk, "\n");
    fprintf(struk, "\n Kasir    : %s                                            %i:%i:%i %i-%i-%i\n", 
                    uname, time_->tm_hour, time_->tm_min, time_->tm_sec, time_->tm_mday, time_->tm_mon+1, time_->tm_year+1900);
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\n Nama Pelanggan      : %s", data.namaPemilik);
    fprintf(struk, "\n Jenis Hewan         : %s", data.namaHewan);
    fprintf(struk, "\n Ras Hewan           : %s", data.jenisHewan);
    fprintf(struk, "\n Kode Penganbilan    : %s", data.kode);
    fprintf(struk, "\n");
    fprintf(struk, "\n Total               : %d", harga_total);
    fprintf(struk, "\n Bayar               : %d", harga_bayar);
    fprintf(struk, "\n Kembalian           : %d", harga_kembalian);
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\n                    Pembayaran dilakukan saat menganbil hewan");
    fprintf(struk, "\n                                    Terimakasih :)");
    fprintf(struk, "\n");
    fprintf(struk, "\n___________________________________________________________________________________");
    fclose(struk);

    system("clear||clr");
    FILE * print_struk;
    char str[MAXCHAR];
    print_struk = fopen("struk.txt", "r");
    while (
        fgets(str, MAXCHAR, print_struk)
        )
        printf("%s", str);
    fclose(print_struk);

    printf("\n*lagi? [y/t] \n > ");
    scanf("%s", &input);
    if (input == 'y')
    {
        return 2;
    }else
    {
        return 3;
    }
}