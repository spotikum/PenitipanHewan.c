#include "main.h"

int main(void) {
    short int kondisi = Guide(), type_user = kondisi;
    while (kondisi != 0)
    {
        if (kondisi == 1 || kondisi == 2)
        {
            kondisi = Head(type_user);
            while (kondisi != 0)
            {
                switch (kondisi)
                {
                case 1: kondisi = Input();
                    break;
                case 2: kondisi = Output();
                    break;
                case 3: printf("Setting");
                    break;
                case 9: kondisi = Head(type_user);
                    break;
                default: printf("Anying1");
                    break;
                }
            }
            kondisi = Guide();
        }
        else if (kondisi == 9)
        {
            kondisi = Guide();
        }else
        {
            printf("Anying2");
            break;
        }
        
    }
    puts("\nBye\n");
    return 0;
}