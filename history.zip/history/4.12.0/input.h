#include <stdio.h>
#include <time.h>

int Input(int user){
    system("clear||clr");
    
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);
        
    // Setting wktu menjadi kode
    // Hari dikali 100 dan bulan dikali 10
    time_->tm_mday *= 100;

    if (time_->tm_mon+1 < 10)
        time_->tm_mon *= 10;
        
    // Pembuatan kode dengan menggabungkan hari dan bulan
    int kode;    
    kode = time_->tm_mday + time_->tm_mon+1;
    if (kode < 1000)
        kode *= 10;
    // end

    // Pembuatan file txt dengan nama dari kode
    char code[13];
    code[0] = 'l';
    code[1] = 'o';
    code[2] = 'g';
    code[3] = '/';
        // Mengubah integer menjadi char
        int tempkode[4];
        tempkode[0] = (kode / 1000);
        tempkode[1] = (kode - (tempkode[0] * 1000)) / 100;
        tempkode[2] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100)))/10;
        tempkode[3] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100) + (tempkode[2] * 10)));
        for (int i = 0; i < 4; i++){
            code[i+4] = tempkode[i]+'0';
        }
        // end
    code[8] = '.';
    code[9] = 't';
    code[10] = 'x';
    code[11] = 't';
    // end

    char namaPemilik[50], namaHewan[7], rasHewan[10];
    int jenisHewan, ras;

    HeadText(); User(user); 
    printf("\nNama Pemilik    : ");
    scanf("%s",&namaPemilik);

    HeadText(); User(user); 
    puts(" ");
    printf("\n\t\t\t[1] Anjing \t[2] Kucing\n\n");
    printf("Jenis Hewan     : ");
    scanf("%d",&jenisHewan);
    if (jenisHewan == 1)
    {
        namaHewan[0] = 'A';
        namaHewan[1] = 'n';
        namaHewan[2] = 'j';
        namaHewan[3] = 'i';
        namaHewan[4] = 'n';
        namaHewan[5] = 'g';

        HeadText(); User(user);
        printf("\n\t\t\t[1] Entah \t[2] Entah2\n\n");
        printf("Ras Hewan     : ");
        scanf("%d", &ras);
        if (ras == 1)
        {
            rasHewan[0] = 'E';
            rasHewan[1] = 'n';
            rasHewan[2] = 't';
            rasHewan[3] = 'a';
            rasHewan[4] = 'h';
        }else if (ras == 2)
        {
            rasHewan[0] = 'E';
            rasHewan[1] = 'n';
            rasHewan[2] = 't';
            rasHewan[3] = 'a';
            rasHewan[4] = 'h';
            rasHewan[5] = '2';
        }
        
    }else if (jenisHewan == 2)
    {
        namaHewan[0] = 'K';
        namaHewan[1] = 'u';
        namaHewan[2] = 'c';
        namaHewan[3] = 'i';
        namaHewan[4] = 'n';
        namaHewan[5] = 'g';

        HeadText(); User(user);
        printf("\n\t\t\t[1] Entah \t[2] Entah2\n\n");
        printf("Ras Hewan     : ");
        scanf("%d", &ras);
        if (ras == 1)
        {
            rasHewan[0] = 'E';
            rasHewan[1] = 'n';
            rasHewan[2] = 't';
            rasHewan[3] = 'a';
            rasHewan[4] = 'h';
        }else if (ras == 2)
        {
            rasHewan[0] = 'E';
            rasHewan[1] = 'n';
            rasHewan[2] = 't';
            rasHewan[3] = 'a';
            rasHewan[4] = 'h';
            rasHewan[5] = '2';
        }
    }

    printf("\n%s\n\n", code);

    // Membuat struk dalam file txt
    FILE * struk;

    struk = fopen("struk.txt", "w");
    fprintf(struk, ".__________________________________________.\n");
    fprintf(struk, "\n");
    fprintf(struk, "               Titip Hewan Kuy\n");
    fprintf(struk, "\n");
    fprintf(struk, " Nama Pemilik      : %s\n", namaPemilik);
    fprintf(struk, " Nama Jenis Hewan  : %s\n", namaHewan);
    fprintf(struk, " Nama Ras Hewan    : %s\n", rasHewan);
    fprintf(struk, " Jenis Hewan       : %d\n", jenisHewan);
    fprintf(struk, " Kode Pengambilan  : %d\n", kode);
    fprintf(struk, ".__________________________________________.\n");
    fclose(struk);
    // end

    // Membuat struk dengan nama dari kode sebagai arsip
    struk = fopen(code, "w");
    fprintf(struk, "%d\n", kode);
    fprintf(struk, "%s\n", namaPemilik);
    fprintf(struk, "%s\n", namaHewan);
    fprintf(struk, "%s\n", rasHewan);
    fprintf(struk, "%d\n", jenisHewan);
    fclose(struk);
    // end

    // Mengulang ke baris awal atau berhenti
    HeadText(); User(user); 
    char input;
    printf("\nLagi? [y/t] : ");
    scanf("%s",&input);
    if (input == 'y'){
        return 1;
    }else{
        return 3;
    }
    // end
}