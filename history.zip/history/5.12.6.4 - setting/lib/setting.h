int Setting();
int ViewUser();
int AddUser();
struct Account;
char uName[MAX_UNAME];

struct Account uac;

int Setting(){
    HeadUser();
    printf("\n\n*Type [ a ] to add user [ v ] to view user [ q ] to back\n\n> ");
    scanf("%c", &input);
    switch (input){
    case 'q': return 9;
    case 'a': return AddUser();
    case 'v': return ViewUser();
    default : return 3;
    }
}

int AddUser(){
    HeadUser();
    printf("\n New Username    : ");
    scanf("%s", &uac.name);
    printf("\n New Password    : ");
    scanf("%s", &uac.pass);
    printf("\n Type of user    : ");
    scanf("%d", &uac.type);
    FILE * add = fopen("file/user.txt", "a");
    fprintf(add,"%s\t%s\t%d\n", uac.name, uac.pass, uac.type);
    fclose(add);
    printf("\n\n *Add user sucsess*\n\n");
    printf("\n*Type any key to continue\n > ");
    scanf("%s", &input);
    return 3;
}

int ViewUser(){
    HeadUser();
    printf("\n\t\t\t   Nama\t\tPwd\tType\n");
    printf("\t\t\t  _____________________________\n");
    FILE * view = fopen("file/user.txt", "r");
    while(!feof(view)){
        fscanf(view,"%s\t%s\t%d", &uac.name, &uac.pass, &uac.type);
        printf("\t\t\t   %s\t%s\t%d\t\n", uac.name, uac.pass, uac.type);
    }
    fclose(view);
    printf("\n*Type any key to continue\n > ");
    scanf("%s", &input);
    return 3;
}