#define MAX_NAMA 20

struct RasHewan{
    char rasHewan[MAX_NAMA];
    int ras;
};
    
struct DataHewan
{
    char namaPemilik[MAX_NAMA];
    char namaHewan[MAX_NAMA];
    int jenisHewan;
};

int Input(){
    system("clear||clr");

    struct RasHewan ras_hewan;
    struct DataHewan data_hewan;
    
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);
        
    // Setting wktu menjadi kode
    // Hari dikali 100 dan bulan dikali 10
    time_->tm_mday *= 100;
        
    // Pembuatan kode dengan menggabungkan hari dan bulan
    int kode;    
    kode = time_->tm_mday + time_->tm_mon+1;
    // end

    // Pembuatan file txt dengan nama dari kode
    char code[13];
    code[0] = 'l';
    code[1] = 'o';
    code[2] = 'g';
    code[3] = '/';
        // Mengubah integer menjadi char
        int tempkode[4];
        tempkode[0] = (kode / 1000);
        tempkode[1] = (kode - (tempkode[0] * 1000)) / 100;
        tempkode[2] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100)))/10;
        tempkode[3] = (kode - ((tempkode[0] * 1000) + (tempkode[1] * 100) + (tempkode[2] * 10)));
        for (int i = 0; i < 4; i++){
            code[i+4] = tempkode[i]+'0';
        }
        // end
    code[8] = '.';
    code[9] = 't';
    code[10] = 'x';
    code[11] = 't';
    // end

    // char namaPemilik[50], namaHewan[7], rasHewan[10];
    // int jenisHewan, ras;

    HeadText(); User(); 
    printf("\nNama Pemilik    : ");
    scanf(" %[^\n]s", data_hewan.namaPemilik);

    HeadText(); User(); 
    puts(" ");
    printf("\n\t\t\t[1] Anjing \t[2] Kucing\n\n");
    printf("Jenis Hewan     : ");
    scanf("%d",&data_hewan.jenisHewan);
    if (data_hewan.jenisHewan == 1)
    {
        strcpy(data_hewan.namaHewan, "Anjing");

        HeadText(); User();
        printf("\n\t\t[1] Small \t[2] Medium \t[3] Large \t[4] Giant\n\n");
        printf("Ras Hewan     : ");
        scanf("%d", &ras_hewan.ras);
        if (ras_hewan.ras == 1)
        {
            strcpy(ras_hewan.rasHewan, "Small");
        }else if (ras_hewan.ras == 2)
        {
            strcpy(ras_hewan.rasHewan, "Medium");
        }else if (ras_hewan.ras == 3)
        {
            strcpy(ras_hewan.rasHewan, "Large");
        }else if (ras_hewan.ras == 4)
        {
            strcpy(ras_hewan.rasHewan, "Giant");
        }
        
    }else if (data_hewan.jenisHewan == 2)
    {
        strcpy(data_hewan.namaHewan, "Kucing");

        HeadText(); User();
        printf("\n\t\t[1] Small \t[2] Medium \t[3] Large \t[4] Giant\n\n");
        printf("Ras Hewan     : ");
        scanf("%d", &ras_hewan.ras);
        if (ras_hewan.ras == 1)
        {
            strcpy(ras_hewan.rasHewan, "Small");
        }else if (ras_hewan.ras == 2)
        {
            strcpy(ras_hewan.rasHewan, "Medium");
        }else if (ras_hewan.ras == 3)
        {
            strcpy(ras_hewan.rasHewan, "Large");
        }else if (ras_hewan.ras == 4)
        {
            strcpy(ras_hewan.rasHewan, "Giant");
        }
    }

    printf("\n%s\n\n", code);

    // Membuat struk dalam file txt
    FILE * struk;

    struk = fopen("struk.txt", "w");
    fprintf(struk, ".__________________________________________.\n");
    fprintf(struk, "\n");
    fprintf(struk, "               Titip Hewan Kuy\n");
    fprintf(struk, "\n");
    fprintf(struk, " Nama Pemilik      : %s\n", data_hewan.namaPemilik);
    fprintf(struk, " Nama Jenis Hewan  : %s\n", data_hewan.namaHewan);
    fprintf(struk, " Nama Ras Hewan    : %s\n", ras_hewan.rasHewan);
    fprintf(struk, " Jenis Hewan       : %d\n", data_hewan.jenisHewan);
    fprintf(struk, " Kode Pengambilan  : %d\n", kode);
    fprintf(struk, ".__________________________________________.\n");
    fclose(struk);
    // end

    // Membuat struk dengan nama dari kode sebagai arsip
    struk = fopen(code, "w");
    fprintf(struk, "%d\n", kode);
    fprintf(struk, "%s\n", data_hewan.namaPemilik);
    fprintf(struk, "%s\n", data_hewan.namaHewan);
    fprintf(struk, "%s\n", ras_hewan.rasHewan);
    fprintf(struk, "%d\n", data_hewan.jenisHewan);
    fclose(struk);
    // end

    // Mengulang ke baris awal atau berhenti
    HeadText(); User(); 
    char input;
    printf("\nLagi? [y/t] : ");
    scanf("%s",&input);
    if (input == 'y'){
        return 1;
    }else{
        return 3;
    }
    // end
}