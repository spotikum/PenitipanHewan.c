#define MAXCHAR 1000
#define MAX_UNAME 15
#define MAX_PASS 8

char uname[MAX_UNAME];

struct Account;
void HeadText();
void User();
int Guide();
int Head();
int Login ();

struct Account {
    char name[MAX_UNAME];
    char pass[MAX_PASS];
};

void HeadText(){
    system("clear||clr");
    FILE * head;
    char str[MAXCHAR];
    head = fopen("file/head.txt", "r");
    while (
        fgets(str, MAXCHAR, head)
        )
        printf("%s", str);
    fclose(head);
}

void User(){
    puts("___________________________________________________________________________________");
    puts(" ");
    printf("\t\t\t\t\t%s\n", uname);
    puts("___________________________________________________________________________________");
}

int Guide(){
    system("clear||clr");
    HeadText();

    char input;
    printf("*Type [ l ] to login [ q ] to exit");
    printf("\n\n> ");
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'l')
    {
        int kode = Login();
        return kode;
    }else{
        return 2;
    }
}

int Head(){
    system("clear||clr");

    HeadText();
    User();

    char input;
    printf("\n*Type [ i ] to input [ o ] to output [ q ] to loguot\n\n");
    printf("%s > ", uname);
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'i'){
        return 1;
    }else if (input == 'o'){
        return 2;
    }else{
        return 3;
    }
}

int Login (){
    char name[MAX_UNAME], pass[MAX_PASS];
    
    printf("Username : ");
    scanf("%s", &name);
    printf("Password : ");
    scanf("%s", &pass);

    FILE *sc;
    struct Account acc;

    sc = fopen("file/user.txt","r");

    for (int i = 0; i < 6; i++)
    {
        fscanf(sc,"%s\t%s", acc.name, acc.pass);
        if(strcmp(name,acc.name) == 0) {
            if (strcmp(pass,acc.pass) == 0)
            {
                strcpy(uname, acc.name);
                return 1;
            }
        }
    }
    printf("\nIncorrect\n");
    getchar();
    fclose(sc);
    return 2;
}