#include <stdio.h>
#include <time.h>
#define Harga 100

int Output(void){
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);

    int kode, hari, bulan;
    printf("Input Kode : ");
    scanf("%d", &kode);
    hari = kode / 100;
    bulan = kode - (hari * 100);

    hari = time_->tm_mday - hari;
    bulan = time_->tm_mon+1 - bulan;
    
    int harga = (Harga * hari) * 1000;

    int bayar, total;
    printf(".__________________________________________\n");
    printf("|\n");
    printf("|               Titip Hewan Kuy\n");
    printf("|\n");
    printf("| \nHarga             : Rp.%d", harga);
    printf("| \nBayar             : Rp."); scanf("%d", &bayar); total = harga - bayar;
    printf("| \nTotal             : Rp.%d\n", total);
    printf("|__________________________________________\n");

    FILE * struk;
    struk = fopen("/home/spot/Desktop/struk.txt", "w");
    fprintf(struk, ".__________________________________________\n");
    fprintf(struk, "|\n");
    fprintf(struk, "|               Titip Hewan Kuy\n");
    fprintf(struk, "|\n");
    fprintf(struk, "| \nHarga             : Rp.%d", harga);
    fprintf(struk, "| \nBayar             : Rp.%d", bayar);
    fprintf(struk, "| \nTotal             : Rp.%d", total);
    fprintf(struk, "|__________________________________________\n");
    fclose(struk);



    char input;
    printf("lagi? [y/t] ");
    scanf("%s", &input);
    printf("kode %c", input);
    if (input == 'y')
    {
        return 2;
    }else
    {
        return 3;
    }
}