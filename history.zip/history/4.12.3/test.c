// #include <stdio.h>
// int main()
// {
//     printf("Enter your name\n");
//     char a[80];
//     gets(a);
//     printf("Your name is %s\n", a);
//     return 0;
// }

#include<stdio.h>
#include<string.h>

int main()
{
    char s1[50];
    char s2[50];

    strcpy(s1, "StudyTonight");     //copies "studytonight" to string s1
    strcpy(s2, s1);     //copies string s1 to string s2

    printf("%s\n", s2);
    
    return(0);
}