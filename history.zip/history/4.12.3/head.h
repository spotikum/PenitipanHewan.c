#include <stdio.h>
#include <stdlib.h>
#define MAXCHAR 1000

void HeadText(){
    system("clear||clr");
    FILE * head;
    char str[MAXCHAR];
    head = fopen("file/head.txt", "r");
    while (
        fgets(str, MAXCHAR, head)
        )
        printf("%s", str);
    fclose(head);
}

void User(int user){
    char namauser[15];
    if (user == 1)
    {
        namauser[0] = 'A';
        namauser[1] = 'd';
        namauser[2] = 'm';
        namauser[3] = 'i';
        namauser[4] = 'n';
    }else
    {
        namauser[0] = 'G';
        namauser[1] = 'u';
        namauser[2] = 'e';
        namauser[3] = 's';
        namauser[4] = 't';
    }

    puts("___________________________________________________________________________________");
    puts(" ");
    printf("\t\t\t\t\t%s\n", namauser);
    puts("___________________________________________________________________________________");
}

int Guide(){
    system("clear||clr");
    printf("\n");

    HeadText();

    char input;
    printf("*Type [ l ] to login [ q ] to exit");
    printf("\n\n> ");
    scanf("%s", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'l')
    {
        int kode = Login();
        return kode;
    }else{
        return 2;
    }
}

int Head(int user){
    system("clear||clr");

    HeadText();
    User(user);

    char input;
    printf("\n*Type [ i ] to input [ o ] to output [ q ] to exit\n\n");
    printf("admin > ");
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'i'){
        return 1;
    }else if (input == 'o'){
        return 2;
    }else{
        return 3;
    }
}

int Login()
{
    char uname[]="admin", password[]="ok", id[20], p[20];
    int n=1, x, y;

    do{
      system("clear||clr");
         printf("\nUsername : ");
         scanf("%s", &id);
         fflush(stdout);

         printf("Password : ");
         scanf("%s", &p);
         fflush(stdout);

         x=strcmp(id, uname);
         y=strcmp(p, password);

         if(x==0 && y==0){
           return 1;
           break;
         }else {
           printf("\nWrong Password, try again", 3-n);
            n++;}

         if(n>5){
          printf("\nAccess Denied");
          }

       }while (n<=5);
    return 0;
}