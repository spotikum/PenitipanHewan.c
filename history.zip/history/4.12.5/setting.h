#include <stdio.h>

int Setting();
int ViewUser();

int Setting(){
    printf("Hello");
    scanf("%c", &input);
    return 9;
}

int ViewUser(){
    printf("Nama\tPwd Type\n");
    FILE * view;
    char str[MAXCHAR];
    view = fopen("file/user.txt", "r");
    while (
        fgets(str, MAXCHAR, view)
        )
        printf("%s", str);
    fclose(view);
}