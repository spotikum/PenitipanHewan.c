#define MAX_NAMA 20

struct DataHewan;
int Input();
int NextKode;
char tmp[MAX_NAMA];
    
struct DataHewan{
    int kode;
    int kode_hewan;
    int jenis_hewan;
    int menit;
    int jam;
    int hari;
    int bulan;
    int ras;
    char telepon[MAX_NAMA];
    char jenisHewan[MAX_NAMA];
    char namaPemilik[MAX_NAMA];
    char namaHewan[MAX_NAMA];
};

int Input(){
    system("clear||clr");
    
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);

    // Buat Kode
    struct DataHewan data;
    FILE *log;
    log = fopen("file/log.txt","r");
    while(!feof(log)){
        fscanf(log,"%d\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s", &data.kode, &tmp, &data.namaPemilik, &data.namaHewan, &data.jenisHewan, 
        &data.kode_hewan, &data.jenis_hewan, &data.menit, &data.jam, &data.hari, &data.bulan, &data.telepon);
    }
    NextKode = data.kode + 1;
    fclose(log);
    // End

    // Input data
    struct DataHewan data_hewan;
    HeadText(); User(); 
	printf("\nNama Pemilik    : ");
	scanf(" %[^\n]s", data_hewan.namaPemilik);
	
	HeadText(); User(); 
	printf("\n\t\t\t[1] Anjing \t[2] Kucing\n\n");
	printf("Jenis Hewan     : ");
	scanf("%d",&data_hewan.jenis_hewan);
	if (data_hewan.jenis_hewan == 1)
	{
		strcpy(data_hewan.namaHewan, "Anjing");
		
		HeadText(); User();
		printf("\n\t\t[1] Small \t[2] Medium \t[3] Large \t[4] Giant\n\n");
		printf("Ras Hewan     : ");
		scanf("%d", &data_hewan.ras);
		if (data_hewan.ras == 1)
		{
			strcpy(data_hewan.jenisHewan, "Small");
		}else if (data_hewan.ras == 2)
		{
			strcpy(data_hewan.jenisHewan, "Medium");
		}else if (data_hewan.ras == 3)
		{
			strcpy(data_hewan.jenisHewan, "Large");
		}else if (data_hewan.ras == 4)
		{
			strcpy(data_hewan.jenisHewan, "Giant");
		}
		
	}else if (data_hewan.jenis_hewan == 2)
	{
		strcpy(data_hewan.namaHewan, "Kucing");
		
		HeadText(); User();
		printf("\n\t\t[1] Small \t[2] Medium \t[3] Large \t[4] Giant\n\n");
		printf("Ras Hewan     : ");
		scanf("%d", &data_hewan.ras);
		if (data_hewan.ras == 1)
		{
			strcpy(data_hewan.jenisHewan, "Small");
		}else if (data_hewan.ras == 2)
		{
			strcpy(data_hewan.jenisHewan, "Medium");
		}else if (data_hewan.ras == 3)
		{
			strcpy(data_hewan.jenisHewan, "Large");
		}else if (data_hewan.ras == 4)
		{
			strcpy(data_hewan.jenisHewan, "Giant");
		}
	}

    HeadText(); User(); 
    printf("\nTelepon         : ");
    scanf("%s", &data_hewan.telepon);
    // End

    FILE *out=fopen("file/log.txt","a");
 	fprintf(out,"%d\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n", NextKode, uname, data_hewan.namaPemilik, 
    data_hewan.namaHewan, data_hewan.jenisHewan, data_hewan.jenis_hewan, data_hewan.jenis_hewan, 
    time_->tm_min, time_->tm_hour, time_->tm_mday, time_->tm_mon+1, data_hewan.telepon);
 	fclose(out);

    FILE * struk = fopen("struk.txt","w");
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\n                              Titip Hewan Kuy");
    fprintf(struk, "\n");
    fprintf(struk, "\n Jln. Kenangan Indah No.1 - Karangasem - Bali");
    fprintf(struk, "\n Hp/Wa 081337335678");
    fprintf(struk, "\n");
    fprintf(struk, "\n Kasir    : %s                                            %i:%i:%i %i-%i-%i\n", 
                    uname, time_->tm_hour, time_->tm_min, time_->tm_sec, time_->tm_mday, time_->tm_mon+1, time_->tm_year+1900);
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\nNama Pelanggan      : %s", data_hewan.namaPemilik);
    fprintf(struk, "\nJenis Hewan         : %s", data_hewan.namaHewan);
    fprintf(struk, "\nRas Hewan           : %s", data_hewan.jenisHewan);
    fprintf(struk, "\nKode Penganbilan    : %d", NextKode);
    fprintf(struk, "\n");
    fprintf(struk, "\n___________________________________________________________________________________");
    fprintf(struk, "\n");
    fprintf(struk, "\n                    Pembayaran dilakukan saat menganbil hewan");
    fprintf(struk, "\n                                    Terimakasih :)");
    fprintf(struk, "\n");
    fprintf(struk, "\n___________________________________________________________________________________");
    fclose(struk);

    system("clear||clr");
    FILE * print_struk;
    char str[MAXCHAR];
    print_struk = fopen("struk.txt", "r");
    while (
        fgets(str, MAXCHAR, print_struk)
        )
        printf("%s", str);
    fclose(print_struk);

    // Mengulang ke baris awal atau berhenti
    // HeadText(); User(); 
    char input;
    printf("\nLagi? [y/t] > ");
    scanf("%s",&input);
    if (input == 'y'){
        return 1;
    }else{
        return 9;
    }
    // end
}