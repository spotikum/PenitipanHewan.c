#define MAXCHAR 1000
#define MAX_NAME 10
#define MAX_UNAME 15
#define MAX_PASS 8

struct Account;
void HeadText(void);
void User(void);
int Guide(void);
int Head(void);
int Head1(void);
int Head2(void);
int Login(void);
char input;
char uname[MAX_UNAME];
int type_user;
short int kondisi;
short int temp;

struct Account {
    char name[MAX_UNAME];
    char pass[MAX_PASS];
    short int type;
};

void HeadText(){
    system("clear||clr");
    FILE * head;
    char str[MAXCHAR];
    head = fopen("file/head.txt", "r");
    while (
        fgets(str, MAXCHAR, head)
        )
        printf("%s", str);
    fclose(head);
}

int GuideText(){
    system("clear||clr");
    FILE * head;
    char str[MAXCHAR];
    head = fopen("file/guide.txt", "r");
    while (
        fgets(str, MAXCHAR, head)
        )
        printf("%s", str);
    fclose(head);
    printf("\n*Type any key to continue\n > ");
    scanf("%d", &temp);
    return 9;
}

void User(){
    char user_type[MAX_NAME];
    if (type_user == 1)
    {
        strcpy(user_type, "Admin");
    }else if (type_user == 2)
    {
        strcpy(user_type, "Pegawai");
    }
    puts("___________________________________________________________________________________");
    puts(" ");
    printf("\t\t\t\t%s - %s\n", uname, user_type);
    puts("___________________________________________________________________________________");
}

int Guide(){
    HeadText();

    puts("___________________________________________________________________________________\n");
    printf("*Type [ l ] to login [ h ] to help [ q ] to exit");
    printf("\n\n> ");
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'l')
    {
        kondisi = Login();
        return kondisi;
    }else if (input == 'h')
    {
        kondisi = GuideText();
        return kondisi;
    }else{
        return 9;
    }
}

int Head(){
    switch (type_user){
    case 1: return Head1();
    case 2: return Head2();
    }
}

int Head1(){
    HeadText();
    User();

    printf("\n*Type [ i ] to input [ o ] to output [ q ] to loguot [ s ] to setting\n\n");
    printf("%s > ", uname);
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'i'){
        return 1;
    }else if (input == 'o'){
        return 2;
    }else if (input == 's'){
        return 3;
    }else{
        return 9;
    }
}

int Head2(){
    HeadText();
    User();

    printf("\n*Type [ i ] to input [ o ] to output [ q ] to loguot\n\n");
    printf("%s > ", uname);
    scanf("%c", &input);
    if (input == 'q'){
        return 0;
    }else if (input == 'i'){
        return 1;
    }else if (input == 'o'){
        return 2;
    }else{
        return 9;
    }
}

int Login (){
    char name[MAX_UNAME], pass[MAX_PASS];
    
    printf("\tUsername : ");
    scanf("%s", &name);
    printf("\tPassword : ");
    scanf("%s", &pass);

    FILE *sc;
    struct Account acc;

    sc = fopen("file/user.txt","r");

    while (!feof(sc))
    {
        fscanf(sc,"%s\t%s\t%d", &acc.name, &acc.pass, &acc.type);
        if(strcmp(name,acc.name) == 0) {
            if (strcmp(pass,acc.pass) == 0)
            {
                strcpy(uname, acc.name);
                type_user = acc.type;
                if (acc.type == 1)
                {
                    return 1;
                }if (acc.type == 2)
                {
                    return 2;
                }
            }
        }
    }
    fclose(sc);
    return 9;
}