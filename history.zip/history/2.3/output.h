#include <stdio.h>
#include <time.h>
#define Harga 100

int Output(void){
    time_t rawtime;
    struct tm*  time_;

    time(&rawtime);
    time_ = localtime(&rawtime);

    int kode, hari, bulan;
    printf("Input Kode : ");
    scanf("%d", &kode);
    hari = kode / 100;
    bulan = kode - (hari * 100);

    hari = time_->tm_mday - hari;
    bulan = time_->tm_mon+1 - bulan;
    
    int harga = (Harga * hari) * 1000;

    FILE * struk;
    struk = fopen("/home/spot/Desktop/struk.txt", "w");
    fprintf(struk, ".__________________________________________\n");
    fprintf(struk, "|\n");
    fprintf(struk, "|               Titip Hewan Kuy\n");
    fprintf(struk, "|\n");
    fprintf(struk, "| Harga             : Rp.%d\n", harga);
    fprintf(struk, "|__________________________________________\n");
    fclose(struk);

    printf(".__________________________________________\n");
    printf("|\n");
    printf("|               Titip Hewan Kuy\n");
    printf("|\n");
    printf("| Harga             : Rp.%d\n", harga);
    printf("|__________________________________________\n");

    char input;
    printf("lagi? [y/t] ");
    scanf("%s", &input);
    printf("kode %c", input);
    if (input == 'y')
    {
        return 2;
    }else
    {
        return 3;
    }
}