#include "head.h"
#include "input.h"
#include "output.h"

int main(void) {
    int kondisi = Help();
    while (kondisi != 0)
    {
        if (kondisi == 1)
        {
            kondisi = Head();
            while (kondisi != 0)
            {
                if (kondisi == 1)
                {
                    kondisi = Input();
                }
                else if (kondisi == 2)
                {
                    kondisi = Output();
                }
                else{
                    kondisi = Head();
                }
            }
            kondisi = Help();
        }
        else if (kondisi == 2)
        {
            kondisi = Help();
        }
    }
    puts("Bye");
    return 0;
}